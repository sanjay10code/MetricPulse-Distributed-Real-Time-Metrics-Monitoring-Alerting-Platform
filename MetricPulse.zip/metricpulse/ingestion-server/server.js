const express = require('express');
const http = require('http');
const { Server } = require('socket.io');
const { Kafka } = require('kafkajs');
const cors = require('cors');
const { InfluxDB, Point } = require('@influxdata/influxdb-client');

const app = express();
app.use(cors());
app.use(express.json());

const server = http.createServer(app);
const io = new Server(server, { cors: { origin: '*' } });

// ─── Config ───────────────────────────────────────────────────────────────────
const CONFIG = {
  kafkaBrokers: (process.env.KAFKA_BROKERS || 'localhost:9092').split(','),
  topic: process.env.KAFKA_TOPIC || 'metrics',
  influxUrl: process.env.INFLUX_URL || 'http://localhost:8086',
  influxToken: process.env.INFLUX_TOKEN || 'my-token',
  influxOrg: process.env.INFLUX_ORG || 'metricpulse',
  influxBucket: process.env.INFLUX_BUCKET || 'metrics',
  port: parseInt(process.env.PORT || '3001'),
  wsPort: parseInt(process.env.WS_PORT || '3002'),
  snsTopicArn: process.env.SNS_TOPIC_ARN || '',
};

// ─── In-Memory Store (fallback when no InfluxDB) ──────────────────────────────
const metricsStore = new Map(); // host -> latest metrics
const metricsHistory = new Map(); // host -> [{timestamp, data}] last 100
const alerts = [];

// ─── InfluxDB ─────────────────────────────────────────────────────────────────
let influxWriteApi = null;
try {
  const influx = new InfluxDB({ url: CONFIG.influxUrl, token: CONFIG.influxToken });
  influxWriteApi = influx.getWriteApi(CONFIG.influxOrg, CONFIG.influxBucket, 'ms');
  console.log('[Server] InfluxDB connected');
} catch(e) {
  console.warn('[Server] InfluxDB unavailable — using in-memory store');
}

function writeToInflux(metrics) {
  if (!influxWriteApi) return;
  try {
    for (const [plugin, data] of Object.entries(metrics.data)) {
      for (const [field, value] of Object.entries(data)) {
        if (typeof value === 'number') {
          const point = new Point(plugin).tag('host', metrics.host).floatField(field, value).timestamp(metrics.timestamp);
          influxWriteApi.writePoint(point);
        }
      }
    }
    influxWriteApi.flush();
  } catch(e) {}
}

// ─── Alert Thresholds ─────────────────────────────────────────────────────────
const THRESHOLDS = {
  'cpu.cpu_usage_percent': { warn: 70, critical: 90 },
  'memory.memory_usage_percent': { warn: 75, critical: 90 },
  'custom_app.error_rate_percent': { warn: 1, critical: 5 },
  'custom_app.response_time_ms': { warn: 150, critical: 500 },
};

function checkAlerts(metrics) {
  const triggered = [];
  for (const [key, threshold] of Object.entries(THRESHOLDS)) {
    const [plugin, field] = key.split('.');
    const value = metrics.data?.[plugin]?.[field];
    if (value === undefined) continue;
    let level = null;
    if (value >= threshold.critical) level = 'critical';
    else if (value >= threshold.warn) level = 'warning';
    if (level) {
      const alert = {
        id: Date.now() + Math.random(),
        host: metrics.host,
        metric: key,
        value,
        threshold: threshold[level],
        level,
        timestamp: metrics.timestamp,
        message: `[${level.toUpperCase()}] ${metrics.host}: ${key} = ${value} (threshold: ${threshold[level]})`,
      };
      triggered.push(alert);
      alerts.unshift(alert);
      if (alerts.length > 100) alerts.pop();
      io.emit('alert', alert);
      console.log(`[ALERT] ${alert.message}`);
    }
  }
  return triggered;
}

// ─── Process Metrics ──────────────────────────────────────────────────────────
function processMetrics(metrics) {
  metricsStore.set(metrics.host, { ...metrics, receivedAt: Date.now() });
  if (!metricsHistory.has(metrics.host)) metricsHistory.set(metrics.host, []);
  const history = metricsHistory.get(metrics.host);
  history.push({ timestamp: metrics.timestamp, data: metrics.data });
  if (history.length > 100) history.shift();
  writeToInflux(metrics);
  checkAlerts(metrics);
  io.emit('metrics', metrics);
}

// ─── Kafka Consumer ───────────────────────────────────────────────────────────
async function startKafkaConsumer() {
  const kafka = new Kafka({ clientId: 'metricpulse-server', brokers: CONFIG.kafkaBrokers });
  const consumer = kafka.consumer({ groupId: 'metricpulse-group' });
  try {
    await consumer.connect();
    await consumer.subscribe({ topic: CONFIG.topic, fromBeginning: false });
    await consumer.run({
      eachMessage: async ({ message }) => {
        try {
          const metrics = JSON.parse(message.value.toString());
          processMetrics(metrics);
        } catch(e) {}
      },
    });
    console.log('[Server] Kafka consumer running');
  } catch(e) {
    console.warn('[Server] Kafka unavailable — WebSocket direct mode only');
  }
}

// ─── WebSocket Direct (from agents without Kafka) ────────────────────────────
const wss = require('ws');
const directWs = new wss.Server({ port: CONFIG.wsPort });
directWs.on('connection', ws => {
  console.log('[Server] Agent connected via WebSocket');
  ws.on('message', data => {
    try { processMetrics(JSON.parse(data)); } catch(e) {}
  });
});
console.log(`[Server] WebSocket agent listener on port ${CONFIG.wsPort}`);

// ─── REST API ─────────────────────────────────────────────────────────────────
app.get('/api/hosts', (req, res) => {
  const hosts = Array.from(metricsStore.entries()).map(([host, data]) => ({
    host,
    lastSeen: data.receivedAt,
    online: Date.now() - data.receivedAt < 30000,
  }));
  res.json(hosts);
});

app.get('/api/metrics/latest', (req, res) => {
  const all = Array.from(metricsStore.values());
  res.json(all);
});

app.get('/api/metrics/:host', (req, res) => {
  const data = metricsStore.get(req.params.host);
  if (!data) return res.status(404).json({ error: 'Host not found' });
  res.json(data);
});

app.get('/api/metrics/:host/history', (req, res) => {
  const history = metricsHistory.get(req.params.host) || [];
  res.json(history);
});

app.get('/api/alerts', (req, res) => res.json(alerts));

app.post('/api/thresholds', (req, res) => {
  const { metric, warn, critical } = req.body;
  THRESHOLDS[metric] = { warn, critical };
  res.json({ success: true, thresholds: THRESHOLDS });
});

app.get('/api/stats', (req, res) => {
  res.json({
    hosts: metricsStore.size,
    totalAlerts: alerts.length,
    criticalAlerts: alerts.filter(a => a.level === 'critical').length,
    uptime: process.uptime(),
    metricsPerSec: metricsStore.size * (1000 / 5000),
  });
});

// ─── Socket.IO ────────────────────────────────────────────────────────────────
io.on('connection', socket => {
  console.log(`[Server] Dashboard connected: ${socket.id}`);
  socket.emit('init', {
    metrics: Array.from(metricsStore.values()),
    alerts: alerts.slice(0, 20),
    thresholds: THRESHOLDS,
  });
});

// ─── Simulate metrics if no agents connected (demo mode) ─────────────────────
function simulateDemoMetrics() {
  const hosts = ['web-server-01', 'web-server-02', 'db-server-01', 'cache-server-01'];
  hosts.forEach(host => {
    const metrics = {
      host,
      timestamp: Date.now(),
      data: {
        cpu: { cpu_usage_percent: parseFloat((Math.random() * 80 + 10).toFixed(2)), cpu_cores: 8 },
        memory: { memory_total_mb: 16384, memory_used_mb: Math.floor(Math.random() * 12000 + 2000), memory_usage_percent: parseFloat((Math.random() * 70 + 20).toFixed(2)) },
        system: { uptime_seconds: Math.floor(Math.random() * 1000000), load_avg_1m: (Math.random() * 4).toFixed(2) },
        custom_app: { requests_per_sec: Math.floor(Math.random() * 500 + 100), error_rate_percent: parseFloat((Math.random() * 2).toFixed(3)), response_time_ms: Math.floor(Math.random() * 200 + 10), active_connections: Math.floor(Math.random() * 1000 + 50) },
      },
    };
    processMetrics(metrics);
  });
}

setInterval(simulateDemoMetrics, 3000);
simulateDemoMetrics();

// ─── Start ────────────────────────────────────────────────────────────────────
server.listen(CONFIG.port, () => console.log(`[Server] MetricPulse ingestion server on port ${CONFIG.port}`));
startKafkaConsumer();
