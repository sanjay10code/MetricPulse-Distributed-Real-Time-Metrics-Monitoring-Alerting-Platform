const os = require('os');
const { Kafka } = require('kafkajs');
const WebSocket = require('ws');

// ─── Config ───────────────────────────────────────────────────────────────────
const CONFIG = {
  kafkaBrokers: (process.env.KAFKA_BROKERS || 'localhost:9092').split(','),
  topic: process.env.KAFKA_TOPIC || 'metrics',
  hostId: process.env.HOST_ID || os.hostname(),
  interval: parseInt(process.env.COLLECT_INTERVAL || '5000'),
  wsUrl: process.env.WS_URL || 'ws://localhost:3002',
};

const kafka = new Kafka({ clientId: `agent-${CONFIG.hostId}`, brokers: CONFIG.kafkaBrokers });
const producer = kafka.producer();

// ─── Plugin Registry ──────────────────────────────────────────────────────────
const plugins = {};

function registerPlugin(name, fn) {
  plugins[name] = fn;
  console.log(`[Agent] Plugin registered: ${name}`);
}

// ─── Built-in Plugins ─────────────────────────────────────────────────────────
registerPlugin('cpu', () => {
  const cpus = os.cpus();
  const usage = cpus.map(cpu => {
    const total = Object.values(cpu.times).reduce((a, b) => a + b, 0);
    const idle = cpu.times.idle;
    return ((1 - idle / total) * 100).toFixed(2);
  });
  return {
    cpu_usage_percent: parseFloat((usage.reduce((a, b) => a + parseFloat(b), 0) / usage.length).toFixed(2)),
    cpu_cores: cpus.length,
    cpu_model: cpus[0].model,
  };
});

registerPlugin('memory', () => {
  const total = os.totalmem();
  const free = os.freemem();
  const used = total - free;
  return {
    memory_total_mb: Math.round(total / 1024 / 1024),
    memory_used_mb: Math.round(used / 1024 / 1024),
    memory_free_mb: Math.round(free / 1024 / 1024),
    memory_usage_percent: parseFloat(((used / total) * 100).toFixed(2)),
  };
});

registerPlugin('system', () => ({
  uptime_seconds: Math.round(os.uptime()),
  load_avg_1m: os.loadavg()[0].toFixed(2),
  load_avg_5m: os.loadavg()[1].toFixed(2),
  load_avg_15m: os.loadavg()[2].toFixed(2),
  platform: os.platform(),
  arch: os.arch(),
}));

registerPlugin('network', () => {
  const interfaces = os.networkInterfaces();
  const addresses = Object.entries(interfaces)
    .flatMap(([name, ifaces]) => ifaces.filter(i => i.family === 'IPv4' && !i.internal).map(i => ({ name, address: i.address })));
  return { network_interfaces: addresses.length, primary_ip: addresses[0]?.address || 'unknown' };
});

// ─── Custom Plugin Example ────────────────────────────────────────────────────
registerPlugin('custom_app', () => ({
  requests_per_sec: Math.floor(Math.random() * 500) + 100,
  error_rate_percent: (Math.random() * 2).toFixed(3),
  response_time_ms: Math.floor(Math.random() * 200) + 10,
  active_connections: Math.floor(Math.random() * 1000) + 50,
}));

// ─── Collect All Metrics ──────────────────────────────────────────────────────
function collectMetrics() {
  const metrics = { host: CONFIG.hostId, timestamp: Date.now(), data: {} };
  for (const [name, fn] of Object.entries(plugins)) {
    try { metrics.data[name] = fn(); }
    catch (e) { console.error(`[Agent] Plugin error (${name}):`, e.message); }
  }
  return metrics;
}

// ─── Send to Kafka ────────────────────────────────────────────────────────────
async function sendToKafka(metrics) {
  await producer.send({
    topic: CONFIG.topic,
    messages: [{ key: CONFIG.hostId, value: JSON.stringify(metrics) }],
  });
}

// ─── Send via WebSocket (fallback) ───────────────────────────────────────────
let ws = null;
function connectWS() {
  try {
    ws = new WebSocket(CONFIG.wsUrl);
    ws.on('open', () => console.log('[Agent] WebSocket connected'));
    ws.on('error', () => { ws = null; });
    ws.on('close', () => { ws = null; setTimeout(connectWS, 5000); });
  } catch(e) { setTimeout(connectWS, 5000); }
}

// ─── Main Loop ────────────────────────────────────────────────────────────────
async function start() {
  console.log(`[Agent] Starting on host: ${CONFIG.hostId}`);
  console.log(`[Agent] Kafka brokers: ${CONFIG.kafkaBrokers.join(', ')}`);
  console.log(`[Agent] Collect interval: ${CONFIG.interval}ms`);
  console.log(`[Agent] Plugins: ${Object.keys(plugins).join(', ')}`);

  try {
    await producer.connect();
    console.log('[Agent] Kafka producer connected');
  } catch(e) {
    console.warn('[Agent] Kafka unavailable, using WebSocket fallback');
    connectWS();
  }

  setInterval(async () => {
    const metrics = collectMetrics();
    try {
      await sendToKafka(metrics);
      process.stdout.write('.');
    } catch(e) {
      if (ws && ws.readyState === WebSocket.OPEN) {
        ws.send(JSON.stringify(metrics));
        process.stdout.write('w');
      }
    }
  }, CONFIG.interval);
}

start().catch(console.error);

// Export for custom plugin registration
module.exports = { registerPlugin };
